﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class _UnitMovement : MonoBehaviour {

//    float dirX, dirY;
  //  public float moveSpeed = 5f;
    //Rigidbody2D rb;

	// Use this for initialization
	void Start () {
      //  rb = GetComponent<Rigidbody2D>();
	}
	
	// Update is called once per frame
	void Update () {
        //dirX = Input.GetAxis("Horizontal");
        //dirY = Input.GetAxis("Vertical");
    }

    private void FixedUpdate()
    {
        //rb.velocity = new Vector2(dirX * moveSpeed, dirY * moveSpeed);
    }
    // When collsion occurs then subtract 10 HP
    private void OnTriggerEnter2D(Collider2D collision)
    {
        //_Health.health -= 10f;
    }

   /* public void MoveUnits()
    {

        try
        {
            Debug.Log("Distance " + Vector2.Distance(transform.position, ClosestUnit.transform.position));
            Debug.Log("AttackRange " + Range);
            if (Vector2.Distance(transform.position, ClosestUnit.transform.position) > Range)
            {

                transform.position = Vector2.MoveTowards(transform.position, ClosestUnit.transform.position, Speed * Time.deltaTime);
            }
        }
        catch
        {
            Debug.Log("catch");
            NewTarget();
        }*/

    }
