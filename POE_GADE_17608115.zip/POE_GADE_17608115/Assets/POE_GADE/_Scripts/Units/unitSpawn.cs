﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class unitSpawn : MonoBehaviour {
    public int MeleeX = 0;
    public int MeleeY = 0;
    public int RangedX = 0;
    public int RangedY = 0;
    public int SiegeX = 0;
    public int SiegeY = 0;
    List<GameObject> units = new List<GameObject>(); // creates the list of units
    public GameObject prefabReference; // a reference to create the units from prefab
    public GameObject prefabReference2; // a reference to create the units from prefab
    public GameObject prefabReference3; // a reference to create the units from prefab

    float spawnSpeed = 10f;
	// Use this for initialization
	void Start () {
        InvokeRepeating("GenerateUnit", 0f, spawnSpeed); // will spawn a unit at the start and continously based off the spawn speed
	}
    public List<GameObject> Units //property for units list
    {
        get { return units; }
    }
    public void RemoveUnit(int index) // remove unit from list
    {
        units.RemoveAt(index);
    }
    public int GetIndex(GameObject unit) //Gives the index of a unit
    {
        return units.IndexOf(unit);
    }
	
	// Update is called once per frame
	void Update () {
		
	}
    public void GenerateUnit() //Method to place units
    {
        GameObject unit = (GameObject)Instantiate(prefabReference); // Creates a unit from the selected prefab
        GameObject unit2 = (GameObject)Instantiate(prefabReference2); // Creates a unit from the selected prefab
        GameObject unit3 = (GameObject)Instantiate(prefabReference3); // Creates a unit from the selected prefab

        unit.transform.position = new Vector3(MeleeX, MeleeY, 1);
        
        SpriteRenderer sprite = unit.GetComponent<SpriteRenderer>();
        sprite.sortingLayerName = "Unit"; // makes sure the unit spawned is on the correct layer

        unit2.transform.position = new Vector3(RangedX, RangedY, 1);
        SpriteRenderer sprite2 = unit2.GetComponent<SpriteRenderer>();
        sprite2.sortingLayerName = "Unit"; // makes sure the unit spawned is on the correct layer

        unit3.transform.position = new Vector3(SiegeX, SiegeY, 1);
        SpriteRenderer sprite3 = unit3.GetComponent<SpriteRenderer>();
        sprite3.sortingLayerName = "Unit"; // makes sure the unit spawned is on the correct layer

    }

}
