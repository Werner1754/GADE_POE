﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Unit : MonoBehaviour
{
    _GameEngine GE = new _GameEngine();
    int closest;

    public int Health
    {
        get;
        set;
    }
    public int Speed
    {
        get;
        set;
    }
    public int Range
    {
        get;
        set;
    }

    public int Damage
    {
        get;
        set;
    }

    public int Faction
    {
        get;
        set;
    }



    // Use this for initialization
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {

    }

    // Michael Code!!!!!!!!!!!!!!!!!!!!!!!!!!
    //public void Newtarget()
    //{
    //    List<GameObject> EnemyUnits;
    //    if (Faction == 1)
    //    {
    //        EnemyUnits = GE.Team1;
    //    }
    //    else
    //    {
    //        EnemyUnits = GE.Team2;
    //    }

    //    Faction = EnemyUnits[0];

    //    foreach (GameObject newT in EnemyUnits)
    //    {
    //        if (Vector2.Distance(transform.position, closest.transform.position) > Vector2.Distance(transform.position, newT.transform.position))
    //        {
    //            closest = newT;
    //        }
    //    }
    //}
    //public void unitMove()
    //{
    //    try
    //    {

    //        if (Vector2.Distance(transform.position, closest.transform.position) > attackRange)
    //        {
    //            transform.position = Vector2.MoveTowards(transform.position, closest.transform.position, Speed * Time.deltaTime);
    //            //Debug.Log(speed);
    //            //Debug.Log(name + "'s position is "+ transform.position.x + " "+ transform.position.y + " and "+closest.GetComponent<Fighter>().name+"'s position is "+ closest.transform.position.x + " " + closest.transform.position.y);
    //        }
    //    }
    //    catch
    //    {
    //        Newtarget();
    //    }
}