﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class _Health : MonoBehaviour

{

  //  ImageConversion healthBar;
  //  float maxHealth = 100f;
   // public static float health;
	// Use this for initialization
	void Start () {
  //      healthBar = GetComponent<image>();
   //     _Health = maxHealth;
	}
	
	// Update is called once per frame
	void Update () {
       // healthBar.fillAmount = health / maxHealth;
	}
}
